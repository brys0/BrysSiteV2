<template>
    <p>
        Nuxt
        <Nuxt/>
    </p>
</template>

<script>
export default {
    name: 'default'
}
</script>

<style lang="sass">

</style>