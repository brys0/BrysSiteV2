import Vue from 'vue'

Vue.mixin({
  mounted() {
    this.$mobile = this.isMobile()
    this.$bypass = this.checkBypass();
  },
  data() {
    return {
      $mobile: true,
      $bypass: false,
    }
  },
  methods: {
    isMobile() {
      if (
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
          navigator.userAgent,
        )
      ) {
        return true
      } else {
        return false
      }
    },
    checkBypass() {
        return localStorage.getItem('bypass') == 'true'
    }
  },
})
