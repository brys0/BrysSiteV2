import Vue from 'vue';
import { MotionPlugin } from '@vueuse/motion';


Vue.use(MotionPlugin);